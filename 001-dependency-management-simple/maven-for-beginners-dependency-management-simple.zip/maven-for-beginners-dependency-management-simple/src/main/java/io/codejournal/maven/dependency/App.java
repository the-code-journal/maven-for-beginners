package io.codejournal.maven.dependency;

public class App {

    public static void main(final String[] args) {
        System.out.println("Hello World!");
    }
}
