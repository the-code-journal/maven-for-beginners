package codejournal.io.maven.dependency;

public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
