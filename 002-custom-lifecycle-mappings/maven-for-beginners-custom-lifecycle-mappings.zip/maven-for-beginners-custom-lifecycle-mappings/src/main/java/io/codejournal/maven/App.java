package io.codejournal.maven;

public class App {

    public static void main(final String[] args) {
        System.out.println("Hello World!");
    }
}
