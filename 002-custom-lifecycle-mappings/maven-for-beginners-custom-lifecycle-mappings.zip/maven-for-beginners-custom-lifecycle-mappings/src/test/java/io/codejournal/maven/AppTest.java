package io.codejournal.maven;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

@RunWith(BlockJUnit4ClassRunner.class)
public class AppTest {

    @Test
    public void testApp() {
        assertTrue(true);
    }
}
